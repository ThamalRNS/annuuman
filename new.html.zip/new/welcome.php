<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <!--<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">-->
    <style>
        body{ font: 14px sans-serif; text-align: center; 
         background-image: url("ima.png");}
         div.form
        {
            display: block;
            text-align: center;
}
        form
{
            display: inline-block;
            margin-left: auto;
            margin-right: auto;
            text-align: left;
}
        body{
            padding: 7%;
            color: white;
            font-size: 23px;
            background-image: url("ima.png");
        }
                div{
            left: 50%;
            margin: 0 auto;
            text-align: center;
            max-width: 

        }
        fieldset{
            margin:0;
            width: 45%;
            border: 0;
            border-radius: 20px;
            margin-left: 25%;
            margin-right: 25%;
            background-color: #006a4e;
            border-color: wheat;
        }
        input{
            border-radius: 20px;
            padding: 5px;
            background-color: wheat;
            border-color: none;
            border:none;
            border-collapse: collapse;
            text-align: center;
        }
    </style>
</head>
<body style="background-color:#336666; ">
    <h1 class="my-5">Hi, <?php echo htmlspecialchars($_SESSION["username"]); ?>. Karibu OCGS .</h1>
        <!--<a href="reset-password.php" class="btn btn-warning">Reset Your Password</a>
        <a href="logout.php" class="btn btn-danger ml-3">Sign Out of Your Account</a>-->
    <div class="form">
<fieldset>
<form action="insert.php" method="POST">
        <center><h3>Aplicant Information</h3></center>
        <label>Full Name:</label>
        <input type="Name" name="fname" placeholder="First Name" required>
        <input type="Name" name="Mname" placeholder="Middle Name" required>
        <input type="Name" name="Lname" placeholder="Last Name"> <br><br>
        <label>Date of Birth:</label>
        <input type="Date" name="DOB">
        <label>Address:</label>
        <input type="Adress" name="Address" placeholder="Address"><br><br>
        <label>Country:</label>
        <input type="Country" name="Country" placeholder="Country">
        <label>City:</label>
        <input type="City" name="City" placeholder="City"><br><br>
        <label>Phone:</label>
        <input type="Phone" name="Phone" placeholder="Telephone Number">
        <label>Email:</label>
        <input type="Email" name="Email" placeholder="Eg: Lukman@gmail.com"><br><br>
        <label>Bank Account Number:</label>
        <input type="text" name="Bank" placeholder="### ### ### ###">
        <label>Position:</label>
        <input type="text" name="Position" placeholder="Applied for"><br>
        <center><h3>Education</h3></center>
        <label>High School Name:</label>
        <input type="text" name="Hschool" placeholder="School Name">
        <label>School Adress: </label>
        <input type="text" name="Saddress" placeholder="School Address"><br><br>
        <label>From:</label>
        <input type="text" name="Fyear1" placeholder="First Year">
        <label>To:</label>
        <input type="text" name="Eyear1" placeholder="End Year"><br><br>
        <label>Collage:</label>
        <input type="text" name="Collage" placeholder="Collage Name">
        <label>Collage Adress:</label>
        <input type="text" name="Caddress" placeholder="Collage Address"><br><br>
        <label>From:</label>
        <input type="text" name="Fyear2" placeholder="First Year">
        <label>To:</label>
        <input type="text" name="Eyear2" placeholder="End Year"><br><br>
        <label>Level OF Education:</label><br><br>
        <input type="radio" name="LOE" value="Certificate"><label>Certificate</label>
        <input type="radio" name="LOE" value="Diploma"><label>Diploma</label>
        <input type="radio" name="LOE" value="Degree"><label>Degree</label>
        <input type="radio" name="LOE" value="Master"><label>Master</label>
        <input type="radio" name="LOE" value="Doctor"><label>Doctor</label><br><br>
        <center><input type="Submit" name="Submit" value="Submit"></center>
</form>
</fieldset>
</div><br><br>
<button><a href="reset-password.php" class="btn btn-warning">Reset Your Password</a></button>
        <button><a href="logout.php" class="btn btn-danger ml-3">Sign Out of Your Account</a></button>
</body>
</meta>
</html>